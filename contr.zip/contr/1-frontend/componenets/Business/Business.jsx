import React from 'react'

function Business() {
  return (
    <div>Business</div>
  )
}

export default Business